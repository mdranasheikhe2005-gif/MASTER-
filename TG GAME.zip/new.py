import telebot
import random
import threading
import time

TOKEN = "7899188333:AAE9Ipyc6EdyjXKa4124BYsD9HfdadR4MGI"
bot = telebot.TeleBot(7899188333)

games = {MASTER 🪓}  # game_id: {"players": {chat_id: {"score":0,"name":name}}, "number":int, "active":bool}
ROUND_TIME = 60  # সেকেন্ডে রাউন্ড সময়

def start_round(game_id):
    games[game_id]["number"] = random.randint(1, 20)
    games[game_id]["active"] = True
    for pid in games[game_id]["players"]:
        bot.send_message(pid, "নতুন রাউন্ড শুরু! 60 সেকেন্ডে guess করো।")

    def end_round():
        time.sleep(ROUND_TIME)
        games[game_id]["active"] = False
        leaderboard = "⏰ রাউন্ড শেষ! Leaderboard:\n"
        sorted_scores = sorted(games[game_id]["players"].items(), key=lambda x: x[1]["score"], reverse=True)
        for idx, (pid, pdata) in enumerate(sorted_scores, start=1):
            leaderboard += f"{idx}. {pdata['name']}: {pdata['score']}\n"
        for pid in games[game_id]["players"]:
            bot.send_message(pid, leaderboard)
        # নতুন রাউন্ড শুরু করতে চাইলে uncomment করো
        # start_round(game_id)

    threading.Thread(target=end_round).start()

@bot.message_handler(commands=['start'])
def start_game(message):
    chat_id = message.chat.id
    user_name = message.from_user.first_name
    if message.text.startswith('/start '):
        game_id = message.text.split()[1]
        if game_id in games:
            games[game_id]["players"][chat_id] = {"score":0,"name":user_name}
            bot.send_message(chat_id, f"{user_name}, তুমি গেমে যোগ হয়েছো! চল খেলা শুরু করি।")
            for pid in games[game_id]["players"]:
                if pid != chat_id:
                    bot.send_message(pid, f"{user_name} যোগ হয়েছে! খেলা চলতে থাকবে।")
            return
    bot.send_message(chat_id, f"হাই {user_name}! /newgame দিয়ে নতুন মাল্টিপ্লেয়ার গেম শুরু করো।")

@bot.message_handler(commands=['newgame'])
def new_game(message):
    chat_id = message.chat.id
    user_name = message.from_user.first_name
    game_id = str(chat_id)+str(random.randint(100,999))
    games[game_id] = {"players":{chat_id: {"score":0,"name":user_name}}, "number":0, "active":False}
    bot_username = bot.get_me().username
    link = f"https://t.me/{bot_username}?start={game_id}"
    bot.send_message(chat_id, f"নতুন গেম শুরু হয়েছে! বন্ধুদের চ্যালেঞ্জ করতে পাঠাও লিঙ্ক:\n{link}")
    start_round(game_id)

@bot.message_handler(commands=['gamelb'])
def game_leaderboard(message):
    chat_id = message.chat.id
    for game_id, data in games.items():
        if chat_id in data["players"]:
            leaderboard = "🏆 Multiplayer Leaderboard 🏆\n"
            sorted_scores = sorted(data["players"].items(), key=lambda x: x[1]["score"], reverse=True)
            for idx, (pid, pdata) in enumerate(sorted_scores, start=1):
                leaderboard += f"{idx}. {pdata['name']}: {pdata['score']}\n"
            bot.send_message(chat_id, leaderboard)
            break

@bot.message_handler(func=lambda message: True)
def guess_number(message):
    chat_id = message.chat.id
    for game_id, data in games.items():
        if chat_id in data["players"] and data["active"]:
            try:
                guess = int(message.text)
                if guess == data["number"]:
                    data["players"][chat_id]["score"] += 1
                    bot.send_message(chat_id, f"সঠিক! তোমার স্কোর: {data['players'][chat_id]['score']}")
                    data["number"] = random.randint(1, 20)
                elif guess < data["number"]:
                    bot.send_message(chat_id, "বেশি চেষ্টা করো!")
                else:
                    bot.send_message(chat_id, "কম চেষ্টা করো!")
            except ValueError:
                bot.send_message(chat_id, "দয়া করে একটি সংখ্যা লিখো।")
            break

bot.polling()